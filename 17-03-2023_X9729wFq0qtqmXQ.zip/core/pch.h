#pragma once

#include <windows.h>
#include <iostream>
#include <memory>
#include <vector>
#include <thread>
#include <chrono>
#include <array>
#include <fstream>
#include <istream>
#include <unordered_map>
#include <intrin.h>
#include <filesystem>
#include <cstdint>
#include <algorithm>
#include <iomanip>
#include <random>
#include <psapi.h>
// :troll:
#define nullpeter nullptr