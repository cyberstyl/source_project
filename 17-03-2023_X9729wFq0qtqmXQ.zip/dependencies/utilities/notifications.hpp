#pragma once
#include "csgo.hpp"

namespace notify {
	void run(std::string text, bool console, bool chat);
}