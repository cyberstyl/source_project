#include <pch.h>
#include "csgo.hpp"

namespace csgo {
	player_t* local_player = nullptr;
	c_usercmd* global_cmd = nullptr;
}
